var app =angular.module('myApp', ['ngRoute']);
app.config(['$routeProvider', function($routeProvider) {
    $routeProvider.
        when('/view', {
        templateUrl: 'view.html',
        controller: 'mycontroller'
    }).
        when('/addpage', {
        templateUrl: 'addpage.html',
        controller: 'mycontroller'
    }).
      otherwise( {
        redirectTo: '/' 
      })

     
}]);
