app.controller('mycontroller',['$scope','$location',function($scope,$location){
    $scope.names=[
	{name:'Harry',phoneNumber:9592329449},
	{name:'Peter',phoneNumber:7696466345},
	{name:'Jorj',phoneNumber:9592324539449}
	];
  $scope.addperson=function(){
	$scope.names.push({
  name:$scope.fname, phoneNumber:$scope.pnumber});
	$scope.fname="";
	$scope.pnumber="";
	$location.path('/view');
	}
$scope.removeProduct=function(name){
	$scope.names.pop(name);
	};

}]);



